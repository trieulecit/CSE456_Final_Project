package com.cse456.flightbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.service.AccountService;

@WebServlet("/login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AccountService accountService;
       
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {		
			
			/* Create session and get input fields variables. */
			
			String phone = request.getParameter("phonenumber");
			String password = request.getParameter("password");
			HttpSession session = request.getSession();
			
			/* Execute login function, IF NOT, print a message. Otherwise, create account session and go to main page. */
			
			if(accountService.doLogin(phone, password)) {			
				session.setAttribute("account", accountService.doGetAccountByPhone(phone));
				Account account = (Account) session.getAttribute("account");				
				System.out.println("Session: " + account.toString());
				if(account != null && account.getType().equals("admin")) {
					response.sendRedirect("view/admin.jsp");
				} else {
					response.sendRedirect("index.jsp");
				}
				
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Login failed!');");
				out.println("location='view/login.jsp';");
				out.println("</script>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void init() {
		accountService = new AccountService();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}
}