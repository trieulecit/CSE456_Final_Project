package com.cse456.flightbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.model.Flight;
import com.cse456.flightbooking.service.FlightService;


@WebServlet("/booking-flight")
public class BookFlightController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FlightService flightService;
       
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			
			/* Get session and input fields variables. */
			
			HttpSession session = request.getSession(true);
			Account account = (Account) session.getAttribute("account");			
			
			
			/* Check condition if account is null, user has to log in. IF NOT, show a message. */
			if(account == null) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Please Log in before booking!');");
				out.println("location='view/login.jsp';");
				out.println("</script>");
			}
			
			/* Check condition if 'radioValue' (default value -1 is not null, then parse the value from 'String' to 'Integer'. IF NOT, show a message. */
			
			int radioValue = -1;
			if(request.getParameter("booking-radio") != null && account != null) {
				radioValue = Integer.parseInt(request.getParameter("booking-radio"));
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Please select a flight piece!');");
				out.println("location='index.jsp#flights';");
				out.println("</script>");
				return;
			}
			
			/* Get the flight corresponding the radio button value, then create a session value to hold that flight and finally redirect to 'booking.jsp' */
			
			Flight flight = (Flight) flightService.doGetAllFlights().get(radioValue);
			session.setAttribute("booking-flight", flight);
			
			response.sendRedirect("view/booking.jsp");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void init() throws ServletException {
		flightService = new FlightService();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}
}