package com.cse456.flightbooking.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.util.AccountUtil;

/* This class supports CRUD data functions with 'account' table */

public class AccountDao {
	/**
	 * Save Account
	 * 
	 * @param account
	 */
	public void saveAccount(Account account) {
		Transaction transaction = null;
		try (Session session = AccountUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the account object
			session.save(account);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	/**
	 * Update Account
	 * 
	 * @param account
	 */
	
	public void updateAccount(Account account) {
		Transaction transaction = null;
		try (Session session = AccountUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the account object
			session.update(account);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	/**
	 * Get Account By ID
	 * 
	 * @param id
	 * @return
	 */
	public Account getAccountById(int id) {

		Transaction transaction = null;
		Account account = null;
		try (Session session = AccountUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// get an Account object
			account = session.get(Account.class, id);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return account;
	}

	/**
	 * Get all Accounts
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Account> getAllAccount() {

		Transaction transaction = null;
		List<Account> listOfAccount = null;
		try (Session session = AccountUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// get an account object

			listOfAccount = session.createQuery("from Account").getResultList();

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfAccount;
	}
	
	/**
	 * Delete User
	 *
	 * @param accountId
	 */
	public void deleteAccount(int accountId) {

		Transaction transaction = null;
		try (Session session = AccountUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			// Delete a Account object
			Account passenger = session.get(Account.class, accountId);
			if (passenger != null) {
				session.delete(passenger);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
}