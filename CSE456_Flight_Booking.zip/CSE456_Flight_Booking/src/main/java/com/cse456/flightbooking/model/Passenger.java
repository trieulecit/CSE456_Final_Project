package com.cse456.flightbooking.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "passenger")
public class Passenger {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "passenger_code")
	private int passengerCode;
	
	@Column(name = "suffix")
	private String suffix;
	
	@Column(name = "full_name")
	private String fullName;
	
	@Column(name = "birthdate")
	private String dateOfBirth;
	
	@Column(name = "email")
	private String email;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "phone")
	private String phone;
	
	@Column(name = "flight_code")
	private	int flightCode;
	
	@Column(name = "account_id")
	private int accountId;
	
	@Column(name = "flight_id")
	private int flightId;
	
	public Passenger() {
		
	}

	public Passenger(String suffix, String fullName, String dateOfBirth, String email, String country, String phone,
			int flightCode, int accountId, int flightId) {
		super();
		this.suffix = suffix;
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.country = country;
		this.phone = phone;
		this.flightCode = flightCode;
		this.accountId = accountId;
		this.flightId = flightId;
	}



	public Passenger(int passengerCode, String suffix, String fullName, String dateOfBirth, String email,
			String country, String phone, int flightCode, int accountId, int flightId) {
		super();
		this.passengerCode = passengerCode;
		this.suffix = suffix;
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.email = email;
		this.country = country;
		this.phone = phone;
		this.flightCode = flightCode;
		this.accountId = accountId;
		this.flightId = flightId;
	}

	@Override
	public String toString() {
		return "Passenger [passengerCode=" + passengerCode + ", suffix=" + suffix + ", fullName=" + fullName
				+ ", dateOfBirth=" + dateOfBirth + ", email=" + email + ", country=" + country + ", phone=" + phone
				+ ", flightCode=" + flightCode + ", accountId=" + accountId + "]";
	}

	public int getPassengerCode() {
		return passengerCode;
	}

	public void setPassengerCode(int passengerCode) {
		this.passengerCode = passengerCode;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getFlightCode() {
		return flightCode;
	}

	public void setFlightCode(int flightCode) {
		this.flightCode = flightCode;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public int getFlightId() {
		return flightId;
	}
	
	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}
}
