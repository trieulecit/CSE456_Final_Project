package com.cse456.flightbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.service.FlightService;

@WebServlet("/edit-flight")
public class EditFlightController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FlightService flightService;
       
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			
			HttpSession session = request.getSession(true);
			Account account = null;
			int flightId = -1;
			
			if(session.getAttribute("account") != null) {
				account = (Account) session.getAttribute("account");
			} else {
				response.sendRedirect("view/login.jsp");
				return;
			}
			
			if(!account.getType().equals("admin")) {
				response.sendRedirect("view/login.jsp");
				return;
			}
			
			if(request.getParameter("edit-flight-id") != null) {
				flightId = Integer.parseInt(request.getParameter("edit-flight-id"));
				session.setAttribute("edit-flight", flightService.doGetFlight(flightId));
				response.sendRedirect("view/updateFlight.jsp");
			} else {
				response.sendRedirect("view/admin.jsp");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void init() throws ServletException {
		flightService = new FlightService();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}
}

