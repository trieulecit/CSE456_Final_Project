package com.cse456.flightbooking.service;

import java.util.ArrayList;
import java.util.List;

import com.cse456.flightbooking.dao.AccountDao;
import com.cse456.flightbooking.model.Account;

public class AccountService {
	private AccountDao accountDao;

	public AccountService() {
		accountDao = new AccountDao();
	}

	/* Get an input account, check condition if that account is validate, return the status at the end. */
	public boolean doRegister(Account account) {
		boolean status = false;

		try {
			if (this.doValidateAccount(account)) {
				accountDao.saveAccount(account);
				status = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return status;
	}
	
	/* Private function, return false value if the input account if the input phone has exist in the database table. */
	private boolean doValidateAccount(Account account) {
		boolean status = true;

		try {
			List<Account> listOfAccounts = doGetAllAccounts();

			for (Account currentAccount : listOfAccounts) {
				if (currentAccount.getPhone().equals(account.getPhone())) {
					status = false;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return status;
	}

	/* Get the input phone and password, check condition if they are belongs to an account in database table, then return true. */
	public boolean doLogin(String phone, String password) {
		boolean status = false;

		try {
			List<Account> listOfAccount = accountDao.getAllAccount();
			
			for(Account account: listOfAccount) {
				if(account.getPhone().equals(phone) && account.getPassword().equals(password)) {
					status = true;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return status;
	}

	/* Get an account from database table by input account's id. */
	public Account doGetAccountById(int accountId) {
		Account account = null;

		try {
			account = accountDao.getAccountById(accountId);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return account;
	}
	
	/* Return an account from database table by input account's phone. */
	public Account doGetAccountByPhone(String phone) {
		Account account = null;

		try {
			List<Account> listOfAccount = accountDao.getAllAccount();
			
			for(Account currentAccount: listOfAccount) {
				if(currentAccount.getPhone().equals(phone)) {
					return currentAccount;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return account;
	}

	/* Return all accounts existing in database table. */
	public List<Account> doGetAllAccounts() {
		List<Account> listOfAccount = new ArrayList<>();

		try {
			listOfAccount = accountDao.getAllAccount();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return listOfAccount;
	}
	
	/* Receive input phone and email, return true while finding out an account with the same phone and email. */
	public boolean doCheckForgottenAccount(String phone, String email) {
		boolean status = false;
		
		try {
			List<Account> listOfAccount = accountDao.getAllAccount();
			
			for(Account account: listOfAccount) {
				if(account.getPhone().equals(phone) && account.getEmail().equals(email)) {
					status = true;
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return status;
	}
	
	/* Receive input account and new password, then update that account in database table. */
	public boolean doChangePassword(Account account, String newPassword) {
		boolean status = false;
		
		try {
			account.setPassword(newPassword);
			accountDao.updateAccount(account);
			status = true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return status;
	}
	
	
	/* Delete all accounts */
	public void doDeleteAllAccount() {
		try {
			List<Account> listOfAccounts = accountDao.getAllAccount();
			
			for(Account account: listOfAccounts) {
				accountDao.deleteAccount(account.getAccountId());				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}