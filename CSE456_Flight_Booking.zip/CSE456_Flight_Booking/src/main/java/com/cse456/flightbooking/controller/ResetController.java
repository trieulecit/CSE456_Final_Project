package com.cse456.flightbooking.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.model.Flight;
import com.cse456.flightbooking.service.AccountService;
import com.cse456.flightbooking.service.FlightService;
import com.cse456.flightbooking.service.PassengerService;

@WebServlet("/reset")
public class ResetController extends HttpServlet {	
	/**
	 * 	This Servlet just supports resetting to change the database status 
	 *  into default, without passengers' information and 0 ordered flight,
	 *  it not affects the account information.
	 */
	private static final long serialVersionUID = 1L;
	private FlightService flightService;
	private PassengerService passengerService;
	private AccountService accountService;

	private void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("Flight data is setting up...");
		
		try {
//			flightService.doDeleteAllNewFlights();
//			
//			for(Flight flight: flightService.doGetAllFlights()) {
//				flightService.doSetDefaultSeat(flight.getFlightId());
//			}
			
			flightService.doDeleteAllFlights();
			passengerService.doDeleteAllPassenger();	
			accountService.doDeleteAllAccount();
			
			accountService.doRegister(new Account("Admin", "Admin", "male", "01/01/2000", "0123456789", "admin@gmail.com", "123", "admin"));
			
			flightService.doAddFlight(new Flight(110, "Ho Chi Minh City", "Da Lat", "12:25", "13:20", "00h55m", "Monday, 22.08.2022", 161000, 0, 100, 1));
			flightService.doAddFlight(new Flight(111, "Ho Chi Minh City", "Da Lat", "12:25", "13:20", "00h55m", "Wednesday, 24.08.2022", 81000, 0, 100, 2));
			flightService.doAddFlight(new Flight(112, "Ho Chi Minh City", "Da Lat", "12:25", "13:20", "00h55m", "Saturday, 27.08.2022", 261000, 0, 150, 3));
			flightService.doAddFlight(new Flight(120, "Da Lat", "Ho Chi Minh City", "14:05", "15:00", "00h55m", "Monday, 22.08.2022", 611000, 0, 100, 4));
			flightService.doAddFlight(new Flight(121, "Da Lat", "Ho Chi Minh City", "14:05", "15:00", "00h55m", "Thursday, 25.08.2022", 261000, 0, 100, 5));
			flightService.doAddFlight(new Flight(122, "Da Lat", "Ho Chi Minh City", "14:05", "15:00", "00h55m", "Saturday, 27.08.2022", 261000, 0, 150, 6));
			flightService.doAddFlight(new Flight(210, "Ho Chi Minh City", "Da Nang", "08:15", "09:50", "01h35m", "Friday, 26.08.2022", 281000, 0, 200, 7));
			flightService.doAddFlight(new Flight(211, "Ho Chi Minh City", "Da Nang", "08:15", "09:50", "01h35m", "Saturday, 27.08.2022", 411000, 0, 200, 8));
			flightService.doAddFlight(new Flight(220, "Da Nang", "Ho Chi Minh City", "22:25", "23:55", "01h30m", "Wednesday, 24.08.2022", 411000, 0, 200, 9));
			flightService.doAddFlight(new Flight(221, "Da Nang", "Ho Chi Minh City", "11:50", "13:25", "01h35m", "Thursday, 25.08.2022", 411000, 0, 200, 10));
			flightService.doAddFlight(new Flight(310, "Ho Chi Minh City", "Nha Trang", "09:05", "10:15", "01h10m", "Tuesday, 23.08.2022", 161000, 0, 200, 11));
			flightService.doAddFlight(new Flight(311, "Ho Chi Minh City", "Nha Trang", "09:05", "10:15", "01h10m", "Friday, 26.08.2022", 1010000, 0, 200, 12));
			flightService.doAddFlight(new Flight(312, "Ho Chi Minh City", "Nha Trang", "09:05", "10:15", "01h10m", "Saturday, 27.08.2022", 762000, 0, 200, 13));
			flightService.doAddFlight(new Flight(320, "Nha Trang", "Ho Chi Minh City", "10:55", "12:05", "01h10m", "Monday, 22.08.2022", 511000, 0, 200, 14));
			flightService.doAddFlight(new Flight(321, "Nha Trang", "Ho Chi Minh City", "10:55", "12:05", "01h10m", "Saturday, 27.08.2022", 161000, 0, 200, 15));
			flightService.doAddFlight(new Flight(410, "Ho Chi Minh City", "Phu Quoc", "05:15", "06:15", "01h00m", "Tuesday, 23.08.2022", 361000, 0, 150, 16));
			flightService.doAddFlight(new Flight(411, "Ho Chi Minh City", "Phu Quoc", "11:50", "12:50", "01h00m", "Friday, 26.08.2022", 1010000, 0, 150, 17));
			flightService.doAddFlight(new Flight(420, "Phu Quoc", "Ho Chi Minh City", "13:35", "14:35", "01h00m", "Monday, 22.08.2022", 511000, 0, 150, 18));
			flightService.doAddFlight(new Flight(421, "Phu Quoc", "Ho Chi Minh City", "23:10", "00:10", "01h00m", "Wednesday, 24.08.2022", 261000, 0, 150, 19));
			flightService.doAddFlight(new Flight(430, "Phu Quoc", "Da Nang", "15:10", "16:55", "01h45m", "Tuesday, 23.08.2022", 691000, 0, 200, 20));
			flightService.doAddFlight(new Flight(431, "Da Nang", "Phu Quoc", "08:30", "10:20", "01h50m", "Saturday, 27.08.2022", 361000, 0, 200, 21));
			
			response.sendRedirect("index.jsp");;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Setting up Completed!");
	}
	
	public void init() {
		flightService = new FlightService();
		passengerService = new PassengerService();
		accountService =  new AccountService();
	}	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.processRequest(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.processRequest(req, resp);
	}
}
