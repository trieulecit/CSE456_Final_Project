package com.cse456.flightbooking.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.cse456.flightbooking.model.Flight;
import com.cse456.flightbooking.util.FlightUtil;

/* This class supports CRUD data functions with 'flights' table */

public class FlightDao {
	
	/**
	 * Save Flight
	 * 
	 * @param flight
	 */
	public void saveFlight(Flight flight) {
		Transaction transaction = null;
		try (Session session = FlightUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the flight object
			session.save(flight);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Update Flight
	 * 
	 * @param flight
	 */
	
	public void updateFlight(Flight flight) {
		Transaction transaction = null;
		try (Session session = FlightUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the student object
			session.update(flight);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	/**
	 * Get User By ID
	 * 
	 * @param flightId
	 * @return
	 */
	public Flight getFlight(int flightId) {

		Transaction transaction = null;
		Flight flight = null;
		try (Session session = FlightUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// get an user object
			flight = session.get(Flight.class, flightId);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return flight;
	}

	/**
	 * Get all Flights
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Flight> getAllFlight() {

		Transaction transaction = null;
		List<Flight> listOfFlight = null;
		try (Session session = FlightUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// get an user object

			listOfFlight = session.createQuery("from Flight").getResultList();

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfFlight;
	}
	
	/**
	 * Delete Flight
	 *
	 * @param flightId
	 */
	public void deleteFlight(int flightId) {

		Transaction transaction = null;
		try (Session session = FlightUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			// Delete a Flight object
			Flight flight = session.get(Flight.class, flightId);
			if (flight != null) {
				session.delete(flight);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
}