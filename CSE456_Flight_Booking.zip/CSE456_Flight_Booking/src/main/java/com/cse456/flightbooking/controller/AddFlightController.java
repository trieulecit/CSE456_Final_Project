package com.cse456.flightbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.model.Flight;
import com.cse456.flightbooking.service.FlightService;


@WebServlet("/add-flight")
public class AddFlightController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private FlightService flightService;
       
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			
			HttpSession session = request.getSession(true);
			Flight flight;
			Account account = null;
			
			if(session.getAttribute("account") != null) {
				account = (Account) session.getAttribute("account");
			} else {
				response.sendRedirect("view/login.jsp");
				return;
			}
			
			if(!account.getType().equals("admin")) {
				response.sendRedirect("view/login.jsp");
				return;
			}
			
			String placeFrom = request.getParameter("from");
			String placeTo = request.getParameter("to");
			String flightCode = request.getParameter("flight-code");
			String date = request.getParameter("date");
			String departureTime = request.getParameter("departure-time");
			String arrivalTime = request.getParameter("arrival-time");
			String duration = request.getParameter("duration");
			String seatsTotal = request.getParameter("total-seats");
			String price = request.getParameter("price");
		
			flight = new Flight(Integer.parseInt(flightCode), placeFrom, placeTo, departureTime, arrivalTime, duration, date, Integer.parseInt(price), 0,Integer.parseInt(seatsTotal));
			
			System.out.println(flight.toString());
			try {
				if(flightService.doAddFlight(flight)) {
					response.sendRedirect("view/admin.jsp");
				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Flight Addition Error!');");
					out.println("location='view/admin.jsp';");
					out.println("</script>");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void init() throws ServletException {
		flightService = new FlightService();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}
}
