package com.cse456.flightbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.service.AccountService;

@WebServlet("/change-password")
public class ChangePasswordController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private AccountService accountService;
       
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			
			/* Get session and input fields variables. */
			
			String newPassword = request.getParameter("new-password");
			String confirmPassword = request.getParameter("confirm-password");
			HttpSession session = request.getSession(true);
			
			
			/* Check condition if the two password fields are not the same, IF NOT, show a message. */
			
			if(!newPassword.equals(confirmPassword)) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('New password and confirm password are not the same!');");
				out.println("location='view/changePassword.jsp';");
				out.println("</script>");
				return;
			}
			
			/* Get the forgotten account from session, IF HAVE NO ACCOUNT (NULL), redirect to the previous page to get that account */
			
			Account account = (Account) session.getAttribute("forgotten-account");
			
			if(account == null) {
				response.sendRedirect("view/forgotPassword.jsp");
			}
			
			/* Execute change-password function and print message if the action is successful or not. */
			
			if(accountService.doChangePassword(account, newPassword)) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Password has been updated!');");
				out.println("location='view/login.jsp';");
				out.println("</script>");
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('UNSUCCESSFUL!');");
				out.println("location='view/changePassword.jsp';");
				out.println("</script>");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public void init() throws ServletException {
		accountService = new AccountService();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}
}