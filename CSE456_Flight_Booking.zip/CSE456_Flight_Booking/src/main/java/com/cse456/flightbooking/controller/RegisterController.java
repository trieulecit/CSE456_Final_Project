package com.cse456.flightbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.service.AccountService;

@WebServlet("/register")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AccountService accountService;

	private void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try (PrintWriter out = response.getWriter()) {
			
			/* Get input fields variables */
			
			String firstName = request.getParameter("first-name");
			String lastName = request.getParameter("last-name");
			String gender = request.getParameter("gender");
			String dob = request.getParameter("dob");
			String password = request.getParameter("password");
			String email = request.getParameter("email");
			String rePassWord = request.getParameter("confirm-password");
			String phone = request.getParameter("phonenumber");
			String type = "normal";
			
			/* Check condition if gender is not null, IF NOT, show a message. */
			/* Check condition if the password fields are the same, IF NOT, show a message. */
			/* Execute register function, show a message if the process is successful or not. */
		
			if (gender != null) {
				if (password.equals(rePassWord)) {
					Account account = new Account(firstName, lastName, gender, dob, phone, email, password, type);
					if (accountService.doRegister(account)) {
						out.println("<script type=\"text/javascript\">");
						out.println("alert('Successfully registered!');");
						out.println("location='view/login.jsp';");
						out.println("</script>");
					} else {
						out.println("<script type=\"text/javascript\">");
						out.println("alert('UNSUCCESSFULLY registered!');");
						out.println("location='view/register.jsp';");
						out.println("</script>");
					}

				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Your password and confirm password are not the same!');");
					out.println("location='view/register.jsp';");
					out.println("</script>");
				}

			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Please fill out your gender!');");
				out.println("location='view/register.jsp';");
				out.println("</script>");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void init() throws ServletException {
		accountService = new AccountService();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.processRequest(request, response);
	}
}