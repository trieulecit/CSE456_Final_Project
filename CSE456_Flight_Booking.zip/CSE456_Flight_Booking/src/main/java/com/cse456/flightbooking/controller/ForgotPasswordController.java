package com.cse456.flightbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cse456.flightbooking.service.AccountService;


@WebServlet("/forgot-password")
public class ForgotPasswordController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AccountService accountService;
       
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			
			/* Getting session and input fields variables. */
			
			String phone = request.getParameter("phone");
			String email = request.getParameter("email");
			HttpSession session = request.getSession(true);
			
			/* Execute condition checking the input account is valid or not, and then print a message. */
			
			if(accountService.doCheckForgottenAccount(phone, email)) {
				session.setAttribute("forgotten-account", accountService.doGetAccountByPhone(phone));
				response.sendRedirect("view/changePassword.jsp");
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Invalid account!');");
				out.println("location='view/forgotPassword.jsp';");
				out.println("</script>");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public void init() throws ServletException {
		accountService = new AccountService();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}
}