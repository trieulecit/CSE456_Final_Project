package com.cse456.flightbooking.service;

import java.util.List;

import com.cse456.flightbooking.dao.FlightDao;
import com.cse456.flightbooking.model.Flight;

public class FlightService {

	private FlightDao flightDao;
	
	public FlightService() {
		this.flightDao = new FlightDao();
	}

	/* Return a flight from database table by flight's id. */
	public Flight doGetFlight(int flightId) {
		Flight flight = null;
		
		try {
			flight = flightDao.getFlight(flightId);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return flight;
	}

	/* Return all flights available in database table. */
	public List<Flight> doGetAllFlights() {
		List<Flight> listOfFlight = null;
		
		try {
			listOfFlight = flightDao.getAllFlight();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return listOfFlight;
	}
	
	/* Delete a flight by flight's id, then return true */
	
	public boolean doDeleteFlight(int flightId) {
		boolean status = false;
		
		try {
			flightDao.deleteFlight(flightId);
			status = true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return status;
	}

	/* *
	 * 
	 * Get the input flight's id, increase flight's code corresponding account seats that have ordered, return true when update successfully. Execute
	 * Execute when booking a flight.
	 * 
	 */
	public boolean doUpdateSeatsOrderedByCode(int flightId) {
		boolean status = false;

		try {
			Flight flight = flightDao.getFlight(flightId);

			int seatsTotal = flight.getSeatsTotal();
			int seatsOrdered = flight.getSeatsOrdered();

			if (seatsOrdered < seatsTotal) {
				flight.setSeatsOrdered(seatsOrdered + 1);
				flightDao.updateFlight(flight);
				status = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return status;
	}
	
	/* Set flight database table into default status */
	public void doSetDefaultSeat(int flightId) {
		Flight flight = flightDao.getFlight(flightId);
		flight.setSeatsOrdered(0);
		flightDao.updateFlight(flight);
	}
	
	/* Delete all flights */
	public void doDeleteAllNewFlights() {
		try {
			List<Flight> listOfFlights = flightDao.getAllFlight();
			
			if(listOfFlights.size() > 20) {
				for(int i = 21; i <= listOfFlights.size(); i++) {
					flightDao.deleteFlight(listOfFlights.get(i).getFlightId());
				}
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void doDeleteAllFlights() {
		try {
			List<Flight> listOfFlights = flightDao.getAllFlight();

			for(Flight flight: listOfFlights) {
				flightDao.deleteFlight(flight.getFlightId());
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean doValidateFlight(Flight flight) {
		boolean status = true;
		
		try {
			List<Flight> listOfFlights = flightDao.getAllFlight();
			
			for(Flight currentflight: listOfFlights) {
				if(flight.getFlightCode() == currentflight.getFlightCode()) {
					status = false;
					break;
				}
			}			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return status;
	}
	
	public boolean doAddFlight(Flight flight) {
		boolean status = false;
		
		try {
			if(this.doValidateFlight(flight)) {
				flightDao.saveFlight(flight);
				status = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return status;
	}
	
	public boolean doUpdateFlight(Flight flight) {
		boolean status = false;		
		try {			
			flightDao.updateFlight(flight);
			status = true;
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return status;
	}
	
	public boolean doCancelTicket(Flight flight) {
		boolean status = false;
		int seatsOrdered = flight.getSeatsOrdered();
		try {
			if(seatsOrdered > 0) {
				flight.setSeatsOrdered(seatsOrdered - 1);
				flightDao.updateFlight(flight);
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return status;
	}
}