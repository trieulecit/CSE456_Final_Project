package com.cse456.flightbooking.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.model.Flight;
import com.cse456.flightbooking.model.Passenger;
import com.cse456.flightbooking.service.PassengerService;


@WebServlet("/submit-passenger")
public class SubmitPassengerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PassengerService passengerService;
       
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			
			/* Get session and input fields variables */
			
			HttpSession session = request.getSession(true);
			
			Account account = (Account) session.getAttribute("account");
			Flight flight = (Flight) session.getAttribute("booking-flight");
			
			String suffix = request.getParameter("suffix");
			String fullName = request.getParameter("full-name");
			String dob = request.getParameter("dob");
			String email = request.getParameter("email");
			String country = request.getParameter("country");
			String phone = request.getParameter("phone");
			String agreeTerm = request.getParameter("agree-term");
			
			/* Check condition if session account is null, IF NOT, show a message and require login. */
			
			if(account == null) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Please Log in before booking!');");
				out.println("location='view/login.jsp';");
				out.println("</script>");
			}
			
			/* Check if the booking flight is null, IF NOT, show a message and return to get the booking flight. */
			
			if(flight == null) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Please choose a flight to book!');");
				out.println("location='http://localhost:8080/Project/index.jsp#flights';");
				out.println("</script>");
			}
			
			if(agreeTerm == null) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Please accept condition!');");
				out.println("location='view/booking.jsp';");
				out.println("</script>");
			}
			
			if(agreeTerm.equals("on")) {
				Passenger passenger = new Passenger();
				
				passenger.setSuffix(suffix);
				passenger.setFullName(fullName);
				passenger.setDateOfBirth(dob);
				passenger.setEmail(email);
				passenger.setCountry(country);
				passenger.setPhone(phone);
				passenger.setFlightCode(flight.getFlightCode());
				passenger.setAccountId(account.getAccountId());
				passenger.setFlightId(flight.getFlightId());
				
				if(passengerService.doAddPassenger(passenger, flight.getFlightId())) {
					session.setAttribute("passenger", flight);	
					response.sendRedirect("view/ticket.jsp");
				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Unsuccessfully Added Passenger!');");
					out.println("location='view/booking.jsp';");
					out.println("</script>");
				}				
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Please accept condition!');");
				out.println("location='view/booking.jsp';");
				out.println("</script>");
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public void init() throws ServletException {
		passengerService = new PassengerService();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.processRequest(request, response);
	}
}