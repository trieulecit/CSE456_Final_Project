package com.cse456.flightbooking.service;

import java.util.ArrayList;
import java.util.List;

import com.cse456.flightbooking.dao.FlightDao;
import com.cse456.flightbooking.dao.PassengerDao;
import com.cse456.flightbooking.model.Account;
import com.cse456.flightbooking.model.Flight;
import com.cse456.flightbooking.model.Passenger;

public class PassengerService {

	private PassengerDao passengerDao;
	private FlightService flightService;

	public PassengerService() {
		passengerDao = new PassengerDao();
		flightService = new FlightService();
	}

	/*
	 * Save the input Passenger into database table and update seat information for
	 * the flight booked, finally return true.
	 */
	public boolean doAddPassenger(Passenger passenger, int flightId) {
		boolean status = false;
		try {

			if (flightService.doUpdateSeatsOrderedByCode(flightId)) {
				passengerDao.savePassenger(passenger);
				status = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return status;
	}

	/* Return a passenger from database table by the passenger's code */
	public Passenger doGetPassengerByCode(int passengerCode) {
		Passenger passenger = null;

		try {
			passenger = passengerDao.getPassengerByCode(passengerCode);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return passenger;
	}

	/* Return a list of all passengers existing in database table */
	public List<Passenger> doGetAllPassengers() {
		List<Passenger> listOfPassenger = new ArrayList<>();

		try {
			listOfPassenger = passengerDao.getAllPassenger();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return listOfPassenger;
	}

	/* Return the list of all Tickets(Passengers) that are registered by the input account */
	public List<Passenger> doGetAllTickets(Account account) {
		List<Passenger> listOfTicket = null;

		try {
			List<Passenger> listOfPassenger = passengerDao.getAllPassenger();
			listOfTicket = new ArrayList<Passenger>();
			for (Passenger passenger : listOfPassenger) {
				if (passenger.getAccountId() == account.getAccountId()) {
					listOfTicket.add(passenger);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

		return listOfTicket;
	}

	/* Delete all existing data in 'passenger' database table */
	public void doDeleteAllPassenger() {
		try {
			List<Passenger> listOfPassenger = passengerDao.getAllPassenger();
			for (Passenger passenger: listOfPassenger) {
				passengerDao.deletePassenger(passenger.getPassengerCode());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean doDeletePassenger(int passengerCode) {
		boolean status = false;
		Passenger passenger = passengerDao.getPassengerByCode(passengerCode);
		Flight flight = flightService.doGetFlight(passenger.getFlightId());
		try {
			if(flightService.doCancelTicket(flight)) {
				passengerDao.deletePassenger(passenger.getPassengerCode());
				status = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return status;
	}
}