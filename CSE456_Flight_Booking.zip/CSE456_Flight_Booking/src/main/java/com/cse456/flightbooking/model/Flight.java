package com.cse456.flightbooking.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "flights")
public class Flight implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8892818195026603291L;

	@Column(name = "flight_code")
	private int flightCode;
	
	@Column(name = "place_from")
	private String placeFrom;
	
	@Column(name = "place_to")
	private String placeTo;
	
	@Column(name = "departure_time")
	private String departureTime;
	
	@Column(name = "arrival_time")
	private String arrivalTime;
	
	@Column(name = "duration")
	private String duration;
	
	@Column(name = "date")
	private String date;
	
	@Column(name = "price")
	private int price;
	
	@Column(name = "seats_ordered")
	private int seatsOrdered;
	
	@Column(name = "seats_total")
	private int seatsTotal;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "flight_id")
	private int flightId;
	
	public Flight() {
		
	}

	public Flight(int flightCode, String placeFrom, String placeTo, String departureTime, String arrivalTime,
			String duration, String date, int price, int seatsOrdered, int seatsTotal) {
		super();
		this.flightCode = flightCode;
		this.placeFrom = placeFrom;
		this.placeTo = placeTo;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.duration = duration;
		this.date = date;
		this.price = price;
		this.seatsOrdered = seatsOrdered;
		this.seatsTotal = seatsTotal;
	}

	public Flight(int flightCode, String placeFrom, String placeTo, String departureTime, String arrivalTime,
			String duration, String date, int price, int seatsOrdered, int seatsTotal, int flightId) {
		super();
		this.flightCode = flightCode;
		this.placeFrom = placeFrom;
		this.placeTo = placeTo;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.duration = duration;
		this.date = date;
		this.price = price;
		this.seatsOrdered = seatsOrdered;
		this.seatsTotal = seatsTotal;
		this.flightId = flightId;
	}

	public int getFlightCode() {
		return flightCode;
	}

	public void setFlightCode(int flightCode) {
		this.flightCode = flightCode;
	}

	public String getPlaceFrom() {
		return placeFrom;
	}

	public void setPlaceFrom(String placeFrom) {
		this.placeFrom = placeFrom;
	}

	public String getPlaceTo() {
		return placeTo;
	}

	public void setPlaceTo(String placeTo) {
		this.placeTo = placeTo;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getSeatsOrdered() {
		return seatsOrdered;
	}

	public void setSeatsOrdered(int seatsOrdered) {
		this.seatsOrdered = seatsOrdered;
	}

	public int getSeatsTotal() {
		return seatsTotal;
	}

	public void setSeatsTotal(int seatsTotal) {
		this.seatsTotal = seatsTotal;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Flight [flightCode=" + flightCode + ", placeFrom=" + placeFrom + ", placeTo=" + placeTo
				+ ", departureTime=" + departureTime + ", arrivalTime=" + arrivalTime + ", duration=" + duration
				+ ", date=" + date + ", price=" + price + ", seatsOrdered=" + seatsOrdered + ", seatsTotal="
				+ seatsTotal + ", flightId=" + flightId + "]";
	}
}