package com.cse456.flightbooking.dao;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.cse456.flightbooking.model.Passenger;
import com.cse456.flightbooking.util.PassengerUtil;

/* This class supports CRUD data functions with 'passenger' table */

public class PassengerDao {
	
	/**
	 * Save Passenger
	 * 
	 * @param passenger
	 */
	public void savePassenger(Passenger passenger) {
		Transaction transaction = null;
		try (Session session = PassengerUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the Passenger object
			session.save(passenger);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Update Passenger
	 * 
	 * @param passenger
	 */
	
	public void updatePassenger(Passenger passenger) {
		Transaction transaction = null;
		try (Session session = PassengerUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the Passenger object
			session.update(passenger);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	/**
	 * Get Passenger By Code
	 * 
	 * @param passengerCode
	 * @return
	 */
	public Passenger getPassengerByCode(int passengerCode) {

		Transaction transaction = null;
		Passenger passenger = null;
		try (Session session = PassengerUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// get an Passenger object
			passenger = session.get(Passenger.class, passengerCode);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return passenger;
	}

	/**
	 * Get all Passengers
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<Passenger> getAllPassenger() {

		Transaction transaction = null;
		List<Passenger> listOfPassenger = null;
		try (Session session = PassengerUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// get an Passenger object

			listOfPassenger = session.createQuery("from Passenger").getResultList();

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfPassenger;
	}
	
	/**
	 * Delete Passenger
	 *
	 * @param id
	 */
	public void deletePassenger(int id) {

		Transaction transaction = null;
		try (Session session = PassengerUtil.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();

			// Delete a Passenger object
			Passenger passenger = session.get(Passenger.class, id);
			if (passenger != null) {
				session.delete(passenger);
			}

			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
}